# prompt_builder.py
