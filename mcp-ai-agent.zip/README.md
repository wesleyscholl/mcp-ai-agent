# MCP AI Agent

Automates GitHub & Jira workflows using MCP and Gemini.